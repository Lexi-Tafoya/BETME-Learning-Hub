/* ============================================================================
   TMR LEARNING EXPERIENCE — LIVE SESSION CLIENT
   Master Electronics | INTERNAL

   Loads after app.js and adds live participant responses to the existing
   presentation without changing a single scene, transition or content file.

   ROLES  (from the URL path)
     /presenter   facilitator console. Drives the session. Notes + controls.
     /display     projected screen. Mirrors the presenter. No controls, no notes.
     anything else (file:// or index.html direct) = STANDALONE BACKUP MODE:
       the presentation behaves exactly as it did before, with responses
       captured on the presenter laptop. Nothing breaks if the server is gone.

   INTEGRATION SEAM
     Server aggregates arrive as {"stepId::key": {optionIndex: count}}, which is
     precisely the shape of app.js's Vote store. They are merged in, so every
     existing chart, histogram and confidence comparison lights up untouched.
   ========================================================================= */
'use strict';

(function () {

  var path = location.pathname.replace(/\/+$/, '');
  var ROLE = path.endsWith('/presenter') ? 'presenter'
           : path.endsWith('/display') ? 'display'
           : 'standalone';

  var LIVE = {
    role: ROLE, online: false, st: null, key: null, es: null,
    lastCountsHash: '', suppress: false
  };
  window.LIVE = LIVE;

  if (ROLE === 'standalone') {
    document.documentElement.setAttribute('data-role', 'standalone');
    return;                      // untouched original behaviour
  }
  document.documentElement.setAttribute('data-role', ROLE);

  var $ = function (s) { return document.querySelector(s); };
  LIVE.key = new URLSearchParams(location.search).get('key') || '';

  /* ---------------------------------------------------------------- transport */
  function post(action, extra) {
    if (ROLE !== 'presenter') return Promise.resolve(null);
    var b = Object.assign({ action: action, key: LIVE.key }, extra || {});
    return fetch('/api/control', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(b)
    }).then(function (r) {
      if (r.status === 401) {
        flash('<b>Facilitator key missing.</b> Open the console from the link the server '
          + 'printed, or from the landing page.');
        return null;
      }
      return r.json();
    }).catch(function () { setOnline(false); return null; });
  }
  LIVE.post = post;

  function connect() {
    if (LIVE.es) { try { LIVE.es.close(); } catch (_) {} }
    LIVE.es = new EventSource('/api/events');
    LIVE.es.onmessage = function (e) {
      setOnline(true);
      try { applyServer(JSON.parse(e.data)); } catch (_) {}
    };
    LIVE.es.onerror = function () { setOnline(false); };
  }

  function setOnline(v) {
    if (LIVE.online === v) return;
    LIVE.online = v;
    var d = $('#liveDot');
    if (d) { d.classList.toggle('on', v); d.title = v ? 'Live session connected' : 'Reconnecting…'; }
    if (!v) flash('<b>Live connection lost.</b> The presentation keeps working — responses '
      + 'can be captured on this laptop until it returns.');
  }

  function flash(m) { if (window.flashMsg) window.flashMsg(m); }

  /* ---------------------------------------------------------------- inbound */
  function applyServer(st) {
    LIVE.st = st;

    // 1. merge anonymous aggregates into the Vote store, then refresh charts
    var hash = JSON.stringify(st.counts);
    if (hash !== LIVE.lastCountsHash) {
      LIVE.lastCountsHash = hash;
      var cur = window.STEPS && window.STEPS[window.State.i];
      var touched = false;
      for (var k in st.counts) {
        var bag = {}, src = st.counts[k];
        for (var opt in src) {
          if (opt === '_texts') continue;
          bag[opt] = src[opt];
        }
        window.State.votes[k] = bag;
        if (cur && k.indexOf(cur.id + '::') === 0) touched = true;
      }
      LIVE.texts = {};
      for (var k2 in st.counts) if (st.counts[k2]._texts) LIVE.texts[k2] = st.counts[k2]._texts;
      if (touched) rerenderCurrent();
    }

    // 2. the display mirrors the presenter's stage exactly
    if (ROLE === 'display') {
      if (st.stepIndex !== window.State.i || st.rv !== window.State.rv) {
        LIVE.suppress = true;
        window.gotoStep(st.stepIndex, st.rv);
        LIVE.suppress = false;
      }
    }
    paintBar();
  }

  function rerenderCurrent() {
    var s = window.STEPS[window.State.i];
    if (!s) return;
    var rv = window.State.rv;
    s._built = false;
    LIVE.suppress = true;
    window.gotoStep(window.State.i, rv);
    LIVE.suppress = false;
  }

  /* Which scenes accept phone responses. Mirrors fields() in join.js. */
  var PHONE_KINDS = {poll:1, rank:1, quiz:1, sort:1, match:1, worksheet:1,
                     builder:1, bias:1, reflect:1};
  function takesPhone(s) {
    if (!s || s.noPhone) return false;
    if (PHONE_KINDS[s.kind]) return true;
    return s.id === 'leader-prep';          // the one prose scene with a phone prompt
  }

  /* ---------------------------------------------------------------- outbound */
  // app.js calls this from inside goto(), so it fires on every real stage change
  LIVE.onStage = function (i, rv) {
    if (ROLE !== 'presenter' || LIVE.suppress) return;
    post('stage', { stepIndex: i, rv: rv });
    // Arriving at a scene that takes phone responses opens it automatically, so
    // pressing Continue is all the facilitator has to do. Manual Close / Reopen
    // stay available in Live controls.
    var s = window.STEPS[i];
    if (!s) return;
    if (takesPhone(s)) {
      if (!LIVE.st || LIVE.st.activity !== s.id) post('open', { stepId: s.id });
    } else if (LIVE.st && LIVE.st.activity) {
      post('open', { stepId: null });        // leaving an activity -> phones wait
    }
  };

  /* ---------------------------------------------------------------- chrome */
  function bar() {
    if ($('#liveBar')) return;
    var b = document.createElement('div');
    b.id = 'liveBar';
    b.className = 'livebar' + (ROLE === 'display' ? ' display' : '');
    b.innerHTML =
      '<span class="ld" id="liveDot" title="Live session"></span>'
      + '<span class="lv" id="lvCode">—</span>'
      + '<span class="lv" id="lvPpl">0 joined</span>'
      + (ROLE === 'presenter' ? '<span class="lv" id="lvSub"></span>' : '');
    document.body.appendChild(b);

    if (ROLE !== 'presenter') return;

    var p = document.createElement('div');
    p.id = 'facPanel';
    p.className = 'facpanel';
    p.innerHTML =
      '<div class="fp-h"><b>Live activity</b><span id="fpName">—</span></div>'
      + '<div class="fp-g">'
      + '<button class="fpb pri" data-a="open">Open activity</button>'
      + '<button class="fpb" data-a="close">Close responses</button>'
      + '<button class="fpb" data-a="reopen">Reopen</button>'
      + '<button class="fpb" data-a="results">Show results</button>'
      + '<button class="fpb" data-a="hide">Hide results</button>'
      + '<button class="fpb" data-a="reveal">Reveal teaching point</button>'
      + '<button class="fpb" data-a="tstart">Start timer</button>'
      + '<button class="fpb" data-a="tpause">Pause</button>'
      + '<button class="fpb" data-a="treset">Reset timer</button>'
      + '<button class="fpb" data-a="qr">Show join QR</button>'
      + '<button class="fpb" data-a="clear">Clear this activity</button>'
      + '<button class="fpb" data-a="export">Export results</button>'
      + '</div>';
    document.body.appendChild(p);

    p.addEventListener('click', function (e) {
      var btn = e.target.closest('[data-a]');
      if (!btn) return;
      var a = btn.getAttribute('data-a');
      var s = window.STEPS[window.State.i];
      if (a === 'open')    post('open', { stepId: s.id });
      if (a === 'close')   post('close');
      if (a === 'reopen')  post('reopen');
      if (a === 'results') post('results', { show: true });
      if (a === 'hide')    post('results', { show: false });
      if (a === 'reveal')  post('reveal', { show: true });
      if (a === 'tstart')  post('timer', { mode: 'start' });
      if (a === 'tpause')  post('timer', { mode: 'pause' });
      if (a === 'treset')  post('timer', { mode: 'reset' });
      if (a === 'clear')   { if (confirm('Clear every response for this activity?'))
                              post('clearStep', { stepId: s.id }); }
      if (a === 'qr')      qrModal();
      if (a === 'export')  window.open('/api/export?key=' + encodeURIComponent(LIVE.key), '_blank');
    });

    var t = document.createElement('button');
    t.id = 'facPanelToggle';
    t.className = 'fptoggle';
    t.type = 'button';
    t.textContent = 'Live controls';
    t.onclick = function () { p.classList.toggle('open'); t.classList.toggle('on'); };
    document.body.appendChild(t);
  }

  function paintBar() {
    var st = LIVE.st; if (!st) return;
    var c = $('#lvCode'), pp = $('#lvPpl'), sub = $('#lvSub'), nm = $('#fpName');
    if (c) c.textContent = 'Code ' + st.code;
    if (pp) pp.textContent = st.participants + (st.participants === 1 ? ' joined' : ' joined');
    if (sub) {
      sub.textContent = st.activity
        ? (st.submitted + ' submitted' + (st.accepting ? '' : ' · closed'))
        : 'no activity open';
    }
    if (nm) {
      var s = st.activity ? window.STEPS.filter(function (x) { return x.id === st.activity; })[0] : null;
      nm.textContent = s ? stripTags(s.title) + (st.accepting ? ' · open' : ' · closed')
                         : 'none open';
    }
  }

  function stripTags(h) {
    var d = document.createElement('div'); d.innerHTML = String(h || '');
    return (d.textContent || '').replace(/\s+/g, ' ').trim();
  }

  /* ---------------------------------------------------------------- QR modal */
  function qrModal() {
    var old = $('#qrScrim'); if (old) { old.remove(); return; }
    var url = location.origin + '/join';
    var d = document.createElement('div');
    d.id = 'qrScrim';
    d.className = 'qrscrim';
    d.innerHTML =
      '<div class="qrbox">'
      + '<p class="kicker">Scan once &middot; keep the page open all session</p>'
      + '<img src="/qr.svg" alt="Join QR code">'
      + '<div class="qrcode">' + (LIVE.st ? LIVE.st.code : '—') + '</div>'
      + '<p class="small">' + url + '</p>'
      + '<p class="small" style="color:var(--ink-4)">No name, no email, no login. '
      + 'Answers are anonymous.</p>'
      + '<button class="go" id="qrClose">Close</button>'
      + '</div>';
    document.body.appendChild(d);
    d.addEventListener('click', function (e) { if (e.target === d) d.remove(); });
    $('#qrClose').onclick = function () { d.remove(); };
  }
  LIVE.qrModal = qrModal;

  /* ---------------------------------------------------------------- boot */
  function boot() {
    bar();
    if (ROLE === 'display') {
      document.body.classList.add('displayrole');
      document.body.classList.remove('fac');
    }
    fetch('/api/state').then(function (r) { return r.json(); }).then(function (st) {
      if (ROLE === 'presenter' && !st.live) post('start');
      applyServer(st);
      if (ROLE === 'presenter') post('stage', { stepIndex: window.State.i, rv: window.State.rv });
      connect();
    }).catch(function () {
      setOnline(false);
      flash('<b>Live session not reachable.</b> Presenting in backup mode — responses can be '
        + 'captured on this laptop.');
    });
  }

  if (document.readyState === 'complete' || document.readyState === 'interactive') {
    setTimeout(boot, 60);
  } else document.addEventListener('DOMContentLoaded', function () { setTimeout(boot, 60); });

})();
