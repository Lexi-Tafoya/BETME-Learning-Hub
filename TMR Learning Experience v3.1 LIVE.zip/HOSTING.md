# Hosting the TMR Learning Experience

**Master Electronics | INTERNAL**

---

## It already runs live, today, with no account

`node server.js` gives you a genuinely working live session on your own laptop:
real URLs, a real scannable QR code, real phones joining, real anonymous
aggregation, real live charts. Participants just need to be on the same Wi-Fi.

**For a workshop in a room, that is the whole answer.** Nothing below is required.

The QR code shipped in `assets/` already encodes your current LAN address:

```
http://192.168.0.76:8080/join
```

If your laptop's address changes, or you move to a different network, regenerate
it in one command:

```bash
python make-qr.py
```

---

## The one thing only you can do

I cannot deploy to a public URL for you, because deployment requires signing in
to a hosting account. Everything is built and configured — the app needs no
build step and no dependencies — so this is genuinely a single action.

### Pick one host and run one command

The app is a zero-dependency Node service. It works unchanged on any of these.

**Option A — Render (simplest, free tier, no CLI)**

1. Go to `render.com` and sign in with your Master Electronics account.
2. **New → Web Service → Deploy from a Git repository** (or use "Deploy an
   existing image / upload"). Point it at a repo containing this folder.
3. Render reads `package.json` and `Procfile` automatically:
   - Build command: *(leave empty — there is nothing to build)*
   - Start command: `node server.js`
4. Add one environment variable so the QR and links use the public address:
   - `PUBLIC_URL` = `https://your-service.onrender.com`
5. Deploy. Then run locally:
   `python make-qr.py https://your-service.onrender.com/join`

**Option B — Azure App Service** (likely the best fit for a Microsoft tenant)

```bash
az login
az webapp up --runtime "NODE:20-lts" --name tmr-workshop --sku B1
az webapp config appsettings set --name tmr-workshop \
  --settings PUBLIC_URL=https://tmr-workshop.azurewebsites.net
```

Then: `python make-qr.py https://tmr-workshop.azurewebsites.net/join`

**Option C — Railway / Fly.io**

`railway up` or `fly launch` from this folder. Both detect Node, use
`npm start`, and need no configuration. Set `PUBLIC_URL` the same way.

### After deploying

| | |
|---|---|
| Main site | `https://<your-host>/` — landing page with all three links |
| Facilitator | `https://<your-host>/presenter?key=…` — the key prints in the host's logs at startup |
| Display | `https://<your-host>/display` |
| Participants | `https://<your-host>/join` |
| QR (live SVG) | `https://<your-host>/qr.svg` |
| QR (PNG) | `https://<your-host>/qr.png` |

Regenerate the QR files for the public URL and you are done:

```bash
python make-qr.py https://<your-host>/join
```

---

## Two things to confirm before a real session on a public host

1. **The facilitator key.** It is printed to the server log at startup and is
   required for every control action. On a public host, read it from the host's
   log stream. Anyone with the key can drive the session, so treat the console
   link as private.

2. **Whether a public host is acceptable at all.** The deck carries an
   **INTERNAL** Purview marking. Participant responses are anonymous and nothing
   is written to disk, but the *content* would be served from outside the
   tenant. Azure App Service inside your own subscription is the cleanest answer
   to that; a public free tier may not be. Worth one check with whoever owns
   data classification before you point a QR code at it.

If the answer is "keep it internal", then the LAN mode you already have is the
right deployment, and no hosting step is needed at all.

---

## Environment variables

| Variable | Purpose | Default |
|---|---|---|
| `PORT` | Listening port | `8080` |
| `PUBLIC_URL` | Overrides the base URL used for the QR and landing links | auto-detected |

## What the server needs

Node 18 or newer. Nothing else. `npm install` does nothing because there are no
dependencies — that is deliberate, so there is no supply chain to review and
nothing to break at startup.
